"""Swing 对话式需求的只读适配：显式发送才调用 apply_turn；商品判断复用 web.evaluate_input。

该模块不使用LLM猜测自由文字、不收集账号、不访问商城、不开放购买。
CLI参数依次是 base64(state JSON), base64(field), base64(submitted text)。
返回 DesktopBridgeClient 的 base64 键值文本协议。
"""
from __future__ import annotations

import base64
from datetime import date
import json
import re
import sys

from .desktop_bridge import encode
from .dialogue_flow import apply_turn, new_dialogue, next_questions
from .web import evaluate_input
from .confirmed_comparison import publish_confirmed_comparison
from .evidence_comparison import digest, number, validate_bundle
from .minimal_research import CASE_ID, selected_pack
from .printer_purchase_checks import HARDWARE_ONLY, build_purchase_checks, render_purchase_checks
from .printer_reviewed_evidence import local_bundle, document_note
from .cognition_comparison import compare as compare_cognition, render as render_cognition

UNKNOWN = {"暂不确定", "不确定", "不知道", "未知", "待确认", "先跳过"}
BOOL = {"是": True, "需要": True, "必须": True, "接受": True,
        "否": False, "不需要": False, "不是必须": False, "不接受": False}
LABELS = {
    "category": "商品品类", "usage": "主要用途", "needs_color": "家中彩印是否必须",
    "idle_weeks_pattern": "连续多周闲置情况",
    "accepts_outsourced_color": "能否外包彩印", "wechat_required": "微信是否必须",
    "accepts_initial_setup": "是否接受首次App/扫码设置",
    "wechat_workflow": "微信打印方式", "device_deployment_region": "打印机使用国家/地区",
    "monthly_pages_range": "月打印页数", "budget_max_cny": "预算（元）",
    "budget_scope": "预算范围", "requires_scan": "扫描功能是否必须",
    "requires_auto_duplex": "自动双面是否必须", "delivery_region": "收货地区",
}
QUESTION = {
    "category": "准备买什么商品？请明确品类（不会从含糊原话自动猜测）。",
    "usage": "主要用来做什么？可用自己的话描述。",
    "idle_weeks_pattern": "家里的打印机是否经常连续多周不用？可暂缓，不作为淘汰条件。",
    "needs_color": "必须在家打印彩色吗？",
    "accepts_outsourced_color": "偶尔需要彩印时，能去打印店处理吗？",
    "wechat_required": "微信打印是必须条件，还是更喜欢但非必须？",
    "accepts_initial_setup": "第一次连接时，能接受使用厂商App和/或扫码完成设置吗？",
    "wechat_workflow": "需要微信小程序直接打印，还是能接受文件转存厂商App？",
    "device_deployment_region": "打印机实际在哪个国家或地区使用？不是收货地。",
    "monthly_pages_range": "每月大约打印多少页？可以输入区间。",
    "budget_max_cny": "这次购买主机的预算上限是多少元？",
    "budget_scope": "预算是否包括运费和另购耗材？",
    "requires_scan": "扫描或复印是否是必须功能？",
    "requires_auto_duplex": "自动双面打印是否必须？",
    "delivery_region": "商品将收货到哪个地区（无需详细住址）？",
}
REFS = {
    "category": [("打印机", "打印机"), ("手机", "手机"), ("电热水壶", "电热水壶")],
    "usage": [("示例：家用打印学习资料", "家用打印学习资料")],
    "idle_weeks_pattern": [("经常连续多周不用", "经常连续多周不用"), ("通常每周都会用", "通常每周都会用")],
    "needs_color": [("是", "是"), ("否", "否")],
    "accepts_outsourced_color": [("是", "是"), ("否", "否")],
    "wechat_required": [("必须", "必须"), ("偏好（非必须）", "不是必须")],
    "accepts_initial_setup": [("接受", "接受"), ("不接受", "不接受")],
    "wechat_workflow": [("微信小程序直接打印", "微信小程序直接打印"),
                        ("文件转存厂商App", "文件转存厂商App")],
    "device_deployment_region": [("示例：中国大陆", "中国大陆")],
    "monthly_pages_range": [("示例：0-50", "0-50")],
    "budget_max_cny": [("示例：1000元", "1000")],
    "budget_scope": [("仅主机硬件", "仅主机硬件"),
                     ("主机含运费及必要支出", "主机含运费及必要支出"),
                     ("含额外耗材", "含额外耗材")],
    "requires_scan": [("是", "是"), ("否", "否")],
    "requires_auto_duplex": [("是", "是"), ("否", "否")],
}
PRINTER_FIELDS = {
    "needs_color", "accepts_outsourced_color", "wechat_required", "accepts_initial_setup",
    "wechat_workflow", "device_deployment_region", "monthly_pages_range", "requires_scan",
    "requires_auto_duplex", "delivery_region", "budget_scope", "idle_weeks_pattern",
}
FIELD_ORDER = (
    "category", "usage", "needs_color", "accepts_outsourced_color",
    "wechat_required", "accepts_initial_setup", "wechat_workflow",
    "device_deployment_region", "monthly_pages_range", "budget_max_cny",
    "requires_scan", "requires_auto_duplex", "budget_scope", "delivery_region", "idle_weeks_pattern",
)


def confirmed_values(state: dict) -> dict:
    return {k: r["value"] for k, r in state["answers"].items()
            if isinstance(r, dict) and r.get("confirmed") is True
            and r.get("origin") == "user_explicit"}


def _valid_state(state: dict) -> dict:
    if not isinstance(state, dict):
        raise ValueError("会话状态必须是对象")
    if type(state.get("version")) is not int or not isinstance(state.get("answers"), dict):
        raise ValueError("会话状态无效")
    if not isinstance(state.get("history"), list) or len(state["history"]) > 30:
        raise ValueError("会话历史无效或过长，请新建会话")
    if len(json.dumps(state, ensure_ascii=False).encode("utf-8")) > 11000:
        raise ValueError("会话状态过长")
    if any(k not in LABELS for k in state["answers"]):
        raise ValueError("存在未允许的条件字段")
    for k, r in state["answers"].items():
        if not isinstance(r, dict) or r.get("origin") != "user_explicit" or r.get("confirmed") is not True:
            raise ValueError("存在未确认的会话字段")
    if "idle_weeks_pattern" in state["answers"]:
        from .dialogue_flow import _check_answer
        _check_answer("idle_weeks_pattern", state["answers"]["idle_weeks_pattern"].get("value"))
        if state["answers"]["idle_weeks_pattern"].get("value") is None:
            raise ValueError("闲置情况不能确认未知值")
    state["purchase_recommendation_approved"] = False
    state["transactions_enabled"] = False
    skipped = state.get("deferred_fields", [])
    if not isinstance(skipped, list) or any(f not in LABELS for f in skipped):
        raise ValueError("待确认字段无效")
    withdrawn=state.get("withdrawn_fields",[])
    if not isinstance(withdrawn,list) or any(f not in LABELS for f in withdrawn) or set(withdrawn)&set(skipped):
        raise ValueError("撤回字段无效")
    return state


def _question_fields(state: dict) -> list[str]:
    v = confirmed_values(state)
    skipped = set(state.get("deferred_fields", [])) | set(state.get("withdrawn_fields", []))
    # 复用现有问答分流，并在聊天入口按最有信息增量的顺序补字段。
    legacy = {q["field"] for q in next_questions(state, limit=3)}
    if "category" not in v:
        return [] if "category" in skipped else ["category"]
    if "usage" not in v and "usage" not in skipped:
        return ["usage"]
    if v["category"] != "printer":
        return [f for f in ("budget_max_cny",) if f not in v and f not in skipped]
    wants_wechat = v.get("wechat_required") is True or "微信" in v.get("usage", "")
    fields = ["needs_color"]
    if v.get("needs_color") is False:
        fields.append("accepts_outsourced_color")
    fields.append("wechat_required")
    if wants_wechat:
        fields.append("accepts_initial_setup")
    if v.get("wechat_required") is True:
        fields.extend(("wechat_workflow", "device_deployment_region"))
    elif wants_wechat and v.get("wechat_required") is False:
        fields.append("device_deployment_region")
    fields.extend(("monthly_pages_range", "budget_max_cny"))
    pending = [f for f in fields if f not in v and f not in skipped and (f in LABELS or f in legacy)]
    if pending or not isinstance(state.get("research_context"), dict):
        return pending
    try:
        selected_pack(state["research_context"])
    except (ValueError, KeyError, TypeError, OSError):
        return pending
    return [f for f in build_purchase_checks(v)["quote_missing"] if f not in skipped]


def _parse(field: str, submitted: str):
    v = submitted.strip()
    if not v or len(v) > 350:
        raise ValueError("请输入1至350字的明确答复，或填写“暂不确定”")
    if v in UNKNOWN:
        return None
    if field in ("needs_color", "accepts_outsourced_color", "wechat_required",
                 "accepts_initial_setup", "requires_scan", "requires_auto_duplex"):
        if field == "wechat_required" and v == "偏好":
            return False
        if v not in BOOL:
            raise ValueError("本问题请明确回复“是/否”或“暂不确定”，其他原话暂不自动判断")
        return BOOL[v]
    if field == "category":
        names = {"打印机": "printer", "printer": "printer", "手机": "phone", "phone": "phone",
                 "电热水壶": "kettle", "kettle": "kettle"}
        if v in names:
            return names[v]
        # 明确提及唯一品类的一句话，只识别品类；附带用途仍需本人下轮确认。
        lead = re.fullmatch(r"(?:我)?(?:想|希望|打算|需要)?(?:买|购买|选购|找)(?:一台|一部|一款|一个|台|部|个)?\s*(打印机|手机|电热水壶)(?:[，,。\s].*)?", v)
        if lead:
            return names[lead.group(1)]
        if not re.fullmatch(r"[\w\u4e00-\u9fff-]{2,30}", v):
            raise ValueError("请单独发送品类名，如“打印机”；需求用途下一轮再描述")
        return v
    if field == "idle_weeks_pattern":
        options = {"经常连续多周不用":"often_long", "通常每周都会用":"usually_short"}
        if v not in options:
            raise ValueError("请选择经常连续多周不用、通常每周都会用，或暂不确定")
        return options[v]
    if field == "budget_max_cny":
        m = re.fullmatch(r"([0-9]{1,8})\s*元?", v)
        if not m:
            raise ValueError("预算请填整数，如1000；示例不是自动确认")
        return int(m.group(1))
    if field == "monthly_pages_range":
        m = re.fullmatch(r"([0-9]{1,6})(?:\s*[-–~至]\s*([0-9]{1,6}))?\s*(?:页)?", v)
        if not m:
            raise ValueError("请填月页数，例如0-50或50")
        lo, hi = int(m.group(1)), int(m.group(2) or m.group(1))
        if lo > hi or hi > 100000:
            raise ValueError("月页数范围无效")
        return [lo, hi]
    if field == "wechat_workflow":
        mapping = {"微信小程序直接打印": "miniprogram", "小程序": "miniprogram",
                   "文件转存厂商App": "transfer_to_app", "厂商App": "transfer_to_app",
                   "转App": "transfer_to_app"}
        if v not in mapping:
            raise ValueError("请选明确的微信方式，或暂不确定")
        return mapping[v]
    if field == "budget_scope":
        mapping = {"仅主机硬件": HARDWARE_ONLY,
                   "主机含运费及必要支出": "device_delivered",
                   "含额外耗材": "device_and_extra_consumables"}
        if v not in mapping:
            raise ValueError("预算口径须选可审选项，或暂不确定")
        return mapping[v]
    return v


def submit_message(state: dict, field: str, submitted: str) -> dict:
    _valid_state(state)
    v = confirmed_values(state)
    withdrawn=set(state.get("withdrawn_fields",[]))
    explicit_withdrawals=set()
    if field == "batch":
        # 明示“字段：答复”的本轮批量提交；不自动拆解随意自然语言。
        if len(submitted) > 1000:
            raise ValueError("本轮批量答复太长")
        lines = [line.strip() for line in submitted.splitlines() if line.strip()]
        if not 1 <= len(lines) <= 8:
            raise ValueError("请每行写一项字段：答复，最多8项")
        labels = {label: name for name, label in LABELS.items()}
        changes = {}
        for line in lines:
            if "：" in line:
                key, value = line.split("：", 1)
            elif ":" in line:
                key, value = line.split(":", 1)
            else:
                raise ValueError("批量答复需要明确字段名和冒号")
            name = labels.get(key.strip(), key.strip())
            if name not in LABELS or name == "category" or name in changes:
                raise ValueError("不支持的/重复的批量字段：" + key.strip())
            if name in PRINTER_FIELDS and v.get("category") != "printer":
                raise ValueError("非打印机不能填打印机条件")
            if value.strip() in ("撤回","撤回答案") and name in v:
                changes[name]=None
                explicit_withdrawals.add(name)
            else:
                changes[name] = _parse(name, value)
    else:
        if field not in LABELS:
            raise ValueError("当前没有可确认的条件字段")
        if field in PRINTER_FIELDS and v.get("category") != "printer":
            raise ValueError("此字段仅适用于打印机，不能跨品类使用")
        if submitted.strip() in ("撤回","撤回答案") and field in v and field!="category":
            parsed=None
            explicit_withdrawals.add(field)
        else:
            parsed = _parse(field, submitted)
        changes = {field: parsed}
        if field == "category" and parsed != v.get("category"):
            # 换品类也要清预算等旧需求，不能把原打印机用户条件当成新商品的确认。
            changes.update({k: None for k in list(v) if k != "category"})
    hardware_only = changes.get("budget_scope") == HARDWARE_ONLY
    # Keep the chat-only hardware ceiling separate from legacy delivered-cost scopes.
    if hardware_only:
        changes["budget_scope"] = "unknown"
    state = apply_turn(state, changes, raw_text=submitted)
    if hardware_only:
        state["answers"]["budget_scope"]["value"] = HARDWARE_ONLY
        turn = state["history"][-1]
        updated = [name for name in turn["changed_fields"] if name != "budget_scope"]
        if v.get("budget_scope") != HARDWARE_ONLY:
            updated.append("budget_scope")
        turn.update(changed_fields=updated, old_conclusions_invalidated=bool(updated))
    skipped = set(state.get("deferred_fields", []))
    for name, value in changes.items():
        withdrawn.discard(name)
        if name in explicit_withdrawals:
            withdrawn.add(name)
            skipped.discard(name)
        elif value is None:
            skipped.add(name)
        else:
            skipped.discard(name)
    if field == "category" and changes.get("category") != v.get("category"):
        skipped = set()
        withdrawn=set()
    if withdrawn or "withdrawn_fields" in state:
        state["withdrawn_fields"]=sorted(withdrawn)
    state["deferred_fields"] = sorted(skipped)
    # 只保留合理有界的本次会话原话；跨会话不自动保存到磁盘。
    return state


def _analysis(state: dict) -> dict | None:
    v = confirmed_values(state)
    if v.get("category") != "printer" or "usage" not in v:
        return None
    budget_scope = v.get("budget_scope", "unknown")
    data = {"category": "printer", "description": v["usage"], "confirmed": True,
            "needs_color": v.get("needs_color"),
            "accepts_outsourced_color": v.get("accepts_outsourced_color"),
            "wechat_required": v.get("wechat_required"),
            "wechat_workflow": v.get("wechat_workflow", "unknown"),
            "device_deployment_region": v.get("device_deployment_region"),
            "monthly_pages_range": v.get("monthly_pages_range"),
            "budget_max_cny": v.get("budget_max_cny"),
            "budget_scope": "unknown" if budget_scope == HARDWARE_ONLY else budget_scope,
            "requires_scan": v.get("requires_scan"),
            "requires_auto_duplex": v.get("requires_auto_duplex"),
            "delivery_region": v.get("delivery_region"),
            # 现有PurchaseRequest暂无首次设置专用字段；将明确拒绝作为待核硬条件，
            # 交由原证据/冲突门禁处理，不能因聊天字段没映射而默认设备可用。
            "requirements": (["必须免去厂商App或扫码首次设置"]
                             if v.get("accepts_initial_setup") is False else [])}
    if "research_context" in state:
        data["research_context"] = state["research_context"]
        data["accepts_initial_setup"] = v.get("accepts_initial_setup")
    return evaluate_input(data)


def _confirmed_comparison_rows(values: dict, legacy_rows: list) -> list:
    """Map explicit current dialogue answers; provider rows supply IDs only."""
    if values.get("category") != "printer":
        return []
    definitions = []
    def add(dimension, value=True, unit="bool", op="eq", manual=False):
        row = {"dimension": dimension, "unit": unit, "op": op,
               "value": value, "importance": "hard"}
        if manual:
            row["requires_manual_resolution"] = True
        definitions.append(row)

    budget = values.get("budget_max_cny")
    if type(budget) is int:
        add("cost", budget, "CNY", "lte")
    if values.get("wechat_required") is True:
        workflow = values.get("wechat_workflow")
        add({"miniprogram": "wechat_miniprogram",
             "transfer_to_app": "wechat_transfer_to_app"}.get(workflow, "wechat_print"))
    for field, dimension in (("requires_scan", "scan"),
                             ("requires_auto_duplex", "auto_duplex"),
                             ("needs_color", "color_print")):
        if values.get(field) is True:
            add(dimension)
    if values.get("accepts_initial_setup") is False:
        add("initial_setup_without_app_or_scan", manual=True)
    # Preserve existing IDs for matching dimensions/units, never their values.
    # Reserve all existing IDs so an omitted condition cannot borrow another ID.
    remaining = {(row["dimension"], row["unit"]): row for row in definitions}
    used_ids = {row["id"] for row in legacy_rows}
    result = []
    for old in legacy_rows:
        key = (old["dimension"], old["unit"])
        if key in remaining:
            result.append(dict(remaining.pop(key), id=old["id"]))
    for row in remaining.values():
        identifier = "confirmed:" + row["dimension"]
        while identifier in used_ids:
            identifier += ":confirmed"
        used_ids.add(identifier)
        result.append(dict(row, id=identifier))
    return result


def _publish_for_chat(analysis: dict, values: dict, version: int, deferred=(), withdrawn=()) -> dict | None:
    """Only accept typed backend data bound to this dialogue; never legacy prose.

    The existing backend provides no typed bundle, so ordinary chat correctly
    falls back to unverified research until that contract is populated.
    """
    if not isinstance(analysis, dict):
        return None
    bundle = analysis.get("verified_research_bundle")
    if not isinstance(bundle, dict):
        return None
    if (bundle.get("category") != values.get("category") or
            type(bundle.get("dialogue_version")) is not int or
            bundle["dialogue_version"] != version or
            bundle.get("confirmed_values_sha256") != digest(values)):
        return None
    # Validate the original bundle before any scoping: slicing must never
    # conceal duplicate IDs, dangling references or oversized collections.
    try:
        validate_bundle(bundle)
    except (ValueError, TypeError, KeyError, OverflowError, AttributeError):
        return None
    requirements = bundle["requirements"]
    facts, sources, candidates = (bundle[k] for k in ("facts", "sources", "candidates"))

    # Budget authority is the user-confirmed main-unit purchase ceiling,
    # not a coincidentally equal consumables limit or a renamed dimension.
    budget = values.get("budget_max_cny")
    cost_rows = [r for r in requirements if r.get("dimension") == "cost"]
    if type(budget) is int:
        if (len(cost_rows) != 1 or cost_rows[0].get("unit") != "CNY" or
                cost_rows[0].get("op") != "lte" or
                cost_rows[0].get("importance") != "hard" or
                type(cost_rows[0].get("value")) is not int or
                cost_rows[0]["value"] != budget):
            return None
        try:
            if any(r.get("unit") == "CNY" and r.get("op") == "lte" and
                   number(r.get("value")) > number(budget) for r in requirements):
                return None
        except (ValueError, TypeError):
            return None
    elif cost_rows:
        return None

    confirmed = _confirmed_comparison_rows(values, requirements)
    # A complete cognition bundle uses the same user-derived full requirements
    # as the default consumer; backend-provided thresholds are never trusted.
    if values.get("category")=="printer" and bundle.get("request_id")=="printer-cognition-pilot":
        from .cognition_comparison import requirements as cognition_requirements
        canonical = cognition_requirements(values)
        if {r["id"] for r in requirements} == {r["id"] for r in canonical}:
            confirmed = canonical
    if not confirmed:
        return None
    # For multi-candidate displays, unresolved newly introduced conditions come
    # first; supplied condition IDs remain in their original relative order.
    if len(candidates) > 1:
        old_ids = {row["id"] for row in requirements}
        confirmed.sort(key=lambda row: row["id"] in old_ids)
    return publish_confirmed_comparison(
        bundle, confirmed, as_of=date.today().isoformat(),
        deployment_region=values.get("device_deployment_region"),
        delivery_region=values.get("delivery_region"),
        budget_scope=values.get("budget_scope"), session_values=values, deferred=deferred, withdrawn=withdrawn)


def _safe_research_progress(state: dict, analysis: dict, values: dict) -> str:
    """Only confirmed user fields and SHA-pinned local pack metadata are publishable.

    The record count measures retained research notes, never verified model facts.
    Free-form report_text/decision_plan/next_action are deliberately ignored.
    """
    count = None
    context = state.get("research_context")
    research = analysis.get("research_case") if isinstance(analysis, dict) else None
    if isinstance(context, dict) and isinstance(research, dict):
        try:
            pack_id, pack = selected_pack(context)
            if research.get("evidence_pack_id") == pack_id:
                count = len(pack["claims"])
        except (ValueError, KeyError, TypeError, OSError):
            pass
    if count is None:
        progress = "当前没有可核对的受控研究包记录数；研究材料仍待核。"
    else:
        progress = f"当前受控研究包包含{count}条待核研究记录；记录数量不代表有效商品证据数。"
    wechat = values.get("wechat_required")
    if wechat is True:
        next_step = "微信打印是用户确认的必须条件：优先查证准确型号如何从微信发起、后续复用的具体条件；目前不能认定支持。"
    elif wechat is False:
        next_step = "微信打印是用户确认的可选条件：可继续核实低频印量、耗材和准确销售型号；微信未核不代表其余研究失败。"
    else:
        next_step = "微信是否必须尚未确认：先向用户澄清，再决定优先核查微信复用还是其他型号条件。"
    budget = values.get("budget_max_cny")
    requirement = (f"用户已确认预算上限为{budget}元；这不是商品售价或有效地区报价。"
                   if type(budget) is int else "用户预算尚未确认；不得推断任何商品满足预算。")
    if count == 0:
        next_research = "本次没有留存待核型号记录；先整理允许使用的来源，再核型号事实。"
    elif count is not None:
        next_research = "已有记录仅供研究排查；继续核原始来源、观察时间、适用型号和地区，不把旧文字当结果。"
    else:
        next_research = "先核实本轮研究包与来源记录是否可用，不能凭空生成商品结论。"
    return "\n".join((progress, requirement, next_step, next_research,
                      "研究资料未经过最终商品事实核验，不能据此推荐购买。"))


def _public_chat_text(public: dict | None, setup_guard: str, progress: str = "") -> str:
    """User-facing text is exclusively authored by this module and the gate."""
    if public is None:
        return (setup_guard + "商品判断：待核研究；本轮没有可对应当前用户需求的有效结构化商品事实。"
                + ("\n" + progress if progress else "")
                + "\n仍需查证：候选型号、匹配条件、原始来源、观察时间、适用地区和有效报价。"
                + "\n下一行动：补齐上述可追溯事实，再重新计算；现有旧研究文字仅留内部审计。"
                + "\n未批准购买，交易关闭，未核实实时价格。")
    lines = [setup_guard + "结构化条件比较（仅对准入事实和规则可核，不是购买许可）："]
    for i, assessment in enumerate(public["assessments"], 1):
        for j, item in enumerate(assessment["comparisons"], 1):
            lines.append(f"候选{i} 条件{j}：{item['text']} "
                         f"核验命题ID：{item['claim_id']}。适用边界：{item['limit']}")
    survivors = [a["candidate_id"] for a in public["assessments"]
                 if a["research_status"] != "excluded_for_research"]
    if not survivors:
        lines.append("整体取舍：原候选均有硬性反证，结束本轮候选比较；调整需求或另找候选。")
    elif public["next_actions"]:
        first = public["next_actions"][0]
        claim = next(c for c in public["claims"] if c["candidate_id"] == first["candidate_id"]
                     and c["requirement_id"] == first["requirement_id"])
        lines.append("下一行动：" + first["candidate_id"] + " / " + claim["dimension"] + "：" + first["description"])
    else:
        lines.append("下一行动：等待新的有效资料，不自动批准购买。")
    lines.append("未批准购买，交易关闭，未核实实时价格。")
    return "\n".join(lines)


def render_chat(state: dict, *, ranking_route=None, ranking_transport=None,
                ranking_budget=None, cost_scenario=None) -> dict:
    _valid_state(state)
    v = confirmed_values(state)
    fields = _question_fields(state)
    active = fields[0] if fields else ""
    prompt = QUESTION[active] if active else "已记录当前明确条件；可点击下方条件修改，或主动预览审计。"
    choices = [*(REFS.get(active, [])), ("暂不确定", "暂不确定")] if active else []
    confirmed = [f"{LABELS.get(k, k)}：{json.dumps(val, ensure_ascii=False)}"
                 for k, val in v.items()]
    missing = [LABELS.get(k, k) for k in fields]
    deferred = [LABELS.get(k, k) for k in state.get("deferred_fields", [])]
    withdrawn = [LABELS.get(k, k) for k in state.get("withdrawn_fields", [])]
    understanding = ("已明确：\n" + ("\n".join(confirmed) if confirmed else "暂无")
                     + "\n\n尚需确认：" + ("、".join(missing) if missing else "当前无必须追问")
                     + ("\n暂不确定：" + "、".join(deferred) if deferred else "")
                     + ("\n已撤回：" + "、".join(withdrawn) if withdrawn else "")
                     + "\n参考答案点击只填草稿，发送后才会被确认为用户原话。")
    analysis = _analysis(state)
    public_decision = None
    purchase_checks = None
    cognition = None
    ranking_audit = None
    if analysis is None:
        outcome = ("尚未选择受审品类或缺用途，先收集需求；未给出商品推荐。"
                   if v.get("category") in (None, "printer")
                   else "该品类目前只能整理需求，尚无可用的专业商品材料；不会返回打印机候选。")
        status = "clarify" if v.get("category") in (None, "printer") else "unsupported"
    else:
        r = analysis["recommendation"]
        setup_guard = ("已确认不接受App/扫码首次设置；现有型号流程材料不足以证明免设置可用，"
                       "此条件先按未核硬要求处理。\n"
                       if v.get("accepts_initial_setup") is False else "")
        reviewed = None
        if not isinstance(analysis.get("verified_research_bundle"), dict):
            reviewed = local_bundle(v, state["version"], _confirmed_comparison_rows(v, []), date.today())
            if reviewed is not None:
                analysis = dict(analysis, verified_research_bundle=reviewed)
        public_decision = _publish_for_chat(analysis, v, state["version"], state.get("deferred_fields", []), state.get("withdrawn_fields", []))
        if public_decision is not None:
            from .cost_scenario import bind_cost
            bind_cost(public_decision, cost_scenario)
            from .action_ranking import rank_actions
            from .cognition_guide import project
            cognition_context = json.loads(project(v, {"public_decision":public_decision}, deferred=state.get("deferred_fields", []), withdrawn=state.get("withdrawn_fields", []))["cognition_context_json"])
            ranked, ranking_audit = rank_actions(public_decision, ranking_route, ranking_transport,
                                                  cognition_context=cognition_context,
                                                  **(ranking_budget or {}))
            public_decision["next_actions"] = ranked
        research_progress = _safe_research_progress(state, analysis, v)
        outcome = _public_chat_text(public_decision, setup_guard, research_progress)
        if reviewed is not None and public_decision is not None:
            # The comparison gate retains claim IDs. Show exact model and
            # dimension names beside the same gate-produced rows.
            outcome += "\n" + "\n".join(
                f"{c['candidate_id']} / {c['dimension']}：{c['status']}；命题ID：{c['claim_id']}"
                for c in public_decision["claims"])
            if type(v.get("budget_max_cny")) is int:
                outcome += f"\n已确认预算上限：{v['budget_max_cny']}元；应付价待核。"
            outcome += "\n" + document_note(reviewed)
        research = analysis.get("research_case")
        if isinstance(research, dict) and research.get("case_id") == CASE_ID:
            purchase_checks = build_purchase_checks(v)
            if public_decision is not None and reviewed is None:
                survivors = {a["candidate_id"] for a in public_decision["assessments"]
                             if a["research_status"] != "excluded_for_research"}
                purchase_checks["candidates"] = [x for x in purchase_checks["candidates"]
                                                   if x["model"] in survivors]
                if public_decision["next_actions"]:
                    first = public_decision["next_actions"][0]
                    purchase_checks["decision_first_action"] = first
                    # The legacy action list cannot override a validated decision.
                    outcome += "\n购买前核价仅作为后续条件；先完成上述统一下一行动。"
                elif not survivors:
                    purchase_checks["decision_first_action"] = None
            else:
                outcome += "\n" + render_purchase_checks(purchase_checks)
        # The local cognition pilot uses the same deterministic claim gate.
        # Never use it to override a provider's validated or rejected bundle.
        if not isinstance(analysis.get("verified_research_bundle"), dict):
            cognition = compare_cognition(v, state["version"], date.today(),
                                          deferred=state.get("deferred_fields", []), withdrawn=state.get("withdrawn_fields", []),
                                          ranking_route=ranking_route,
                                          ranking_transport=ranking_transport,
                                          ranking_budget=ranking_budget, cost_scenario=cost_scenario)
            if cognition is not None:
                outcome = (setup_guard + render_cognition(cognition, v)
                           + "\n旧研究材料（待核研究，不影响上述有据维度）：\n"
                           + research_progress)
                decision = cognition["decision"]
                ranking_audit = cognition["ranking_audit"]
                action = decision["next_action"]
                if purchase_checks is not None:
                    # Keep quote/fee audit fields, but never recommend actions for
                    # an excluded candidate or contradict the selected next step.
                    survivors = {r["model"] for r in decision["candidates"] if not r["failed"]}
                    purchase_checks["candidates"] = [x for x in purchase_checks["candidates"]
                                                     if x["model"] in survivors]
                    if survivors:
                        from .printer_purchase_checks import SCOPE_LABELS
                        scope = SCOPE_LABELS.get(purchase_checks["budget_scope"], "费用范围待确认")
                        outcome += "\n购买前核价（仅保留研究候选）：预算费用范围 " + scope + "；实际价格待核。"
                field = action["field"]
                if field and field not in state.get("deferred_fields", []):
                    active = field
                    fields = [field] + [f for f in fields if f != field]
                    prompt = QUESTION[field]
                    choices = [*REFS[field], ("暂不确定", "暂不确定")]
                else:
                    active = ""
                    prompt = action["text"]
                    choices = []

        if public_decision is not None and reviewed is None and cognition is None:
            from .cost_scenario import render_cost
            outcome += "\n" + render_cost(public_decision.get("cost_comparison"))
            if not any(a["research_status"] != "excluded_for_research"
                       for a in public_decision["assessments"]):
                active, choices = "", []
                prompt = "原候选均有硬性反证，结束本轮候选比较；调整需求或另找候选。"
                if purchase_checks is not None:
                    purchase_checks["candidates"] = []
            elif public_decision["next_actions"]:
                first = public_decision["next_actions"][0]
                claim = next(c for c in public_decision["claims"]
                             if c["candidate_id"] == first["candidate_id"]
                             and c["requirement_id"] == first["requirement_id"])
                if first["kind"]=="clarify":
                    active={"scan":"requires_scan","auto_duplex":"requires_auto_duplex"}[claim["dimension"]]
                    prompt=QUESTION[active]
                    choices=[*REFS[active], ("暂不确定","暂不确定")]
                    fields=[active]+[f for f in fields if f!=active]
                else:
                    active, choices = "", []
                    prompt = first["description"] if first["kind"]=="confirm_cost_assumption" else first["candidate_id"] + " / " + claim["dimension"] + "：" + first["description"]
        # The status remains a dialogue workflow signal, never a verified
        # product claim. Only the gate-generated text can be published as such.
        status = r["status"]
    editable = "\n".join(f"{k}\t{LABELS[k]}\t{json.dumps(v[k], ensure_ascii=False) if k in v else '待确认'}"
                          for k in FIELD_ORDER
                          if (v.get("category") == "printer" or k not in PRINTER_FIELDS))
    report = {"dialogue": state, "confirmed_fields": v,
              "unconfirmed_fields": fields, "deferred_fields": state.get("deferred_fields", []),
              "withdrawn_fields":state.get("withdrawn_fields", []),
              "research_result": analysis,
              "legacy_unverified_research": analysis is not None,
              "public_decision": public_decision,
              "purchase_checks": purchase_checks,
              "cognition_comparison": cognition,
              "ranking_audit": ranking_audit,
              "public_claim_source": "publish_checked_comparison" if public_decision else "unverified_research_only",
              "purchase_recommendation_approved": False, "transactions_enabled": False,
              "live_price_verified": False}
    from .cognition_guide import project
    guide = project(v, report, deferred=state.get("deferred_fields", []), withdrawn=state.get("withdrawn_fields", []))
    if guide:
        guide_context = json.loads(guide["cognition_context_json"])
        report["cognition_guidance"] = guide_context
        task = guide_context["usage_research"]
        if task["status"] == "research_required":
            outcome += "\n使用场景补证（不改变硬条件优先级）：" + task["question"]
        if active == "needs_color" and "usage" in v:
            prompt = "先看选购指南：必须在家打印彩色吗？黑白资料和偶尔彩印可分开考虑。"
    if guide:
        from .decision_note import render_note
        guide["decision_note_json"]=render_note(report,guide,prompt)
    return {"status": status, "state_json": json.dumps(state, ensure_ascii=False),
            "prompt_field": active, "prompt": prompt,
            "choices": "\n".join(label + "\t" + draft for label, draft in choices),
            "understanding": understanding, "result_text": outcome,
            "editable": editable, "session_version": str(state["version"]),
            "report_json": json.dumps(report, ensure_ascii=False, indent=2), **guide}


def main() -> None:
    try:
        args = sys.argv[1:]
        if args == ["--worksheet-stdin"]:
            from .decision_worksheet import handle, parse, MAX_BYTES
            out = handle(parse(sys.stdin.buffer.read(MAX_BYTES + 1)))
            for key, value in out.items():
                print(key + "\t" + encode(value))
            return
        if len(args) != 3:
            raise ValueError("需要状态、条件字段和本轮发送原话")
        raw = [base64.b64decode(x, validate=True).decode("utf-8") for x in args]
        state = new_dialogue() if not raw[0] else json.loads(raw[0])
        if raw[1] or raw[2]:
            state = submit_message(state, raw[1], raw[2])
        out = render_chat(state)
    except (ValueError, TypeError, KeyError, UnicodeError, json.JSONDecodeError, RecursionError, OverflowError) as exc:
        out = {"error": str(exc)}
    for key, value in out.items():
        print(key + "\t" + encode(value))


if __name__ == "__main__":
    main()
